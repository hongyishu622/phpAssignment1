let para = document.querySelector("p");
let clear = document.querySelector("button");
clear.onclick = () => {
	para.remove();
};
